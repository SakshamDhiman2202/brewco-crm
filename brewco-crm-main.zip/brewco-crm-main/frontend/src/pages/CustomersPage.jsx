import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Mail, MapPin, Search, ShoppingBag, UserRound, WalletCards, X } from "lucide-react";
import EmptyState from "@/components/common/EmptyState";
import ErrorState from "@/components/common/ErrorState";
import LoadingSkeleton from "@/components/common/LoadingSkeleton";
import PageHeader from "@/layout/PageHeader";
import { useCustomers } from "@/hooks/useCustomers";

const currencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0
});

function formatCurrency(value) {
  return currencyFormatter.format(Number(value || 0));
}

function formatDate(value) {
  if (!value) {
    return "Not available";
  }

  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  }).format(new Date(value));
}

import { getCustomerHealth } from "@/utils/customerHealth";

function HealthBadge({ value }) {
  const styles = {
    VIP: "bg-brew-amber/15 text-brew-roast ring-brew-amber/30",
    "At Risk": "bg-red-100 text-red-800 ring-red-200",
    Active: "bg-green-100 text-green-800 ring-green-200",
    Unscored: "bg-brew-brown/10 text-brew-roast ring-brew-brown/20"
  };

  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${styles[value] || styles.Unscored}`}>
      {value}
    </span>
  );
}

function DetailItem({ icon: Icon, label, value, className = "" }) {
  return (
    <div className={`min-w-0 rounded-lg border border-brew-brown/10 bg-brew-cream p-4 ${className}`}>
      <div className="flex items-center gap-2 text-xs font-medium uppercase text-brew-roast">
        <Icon size={15} />
        {label}
      </div>
      <p className="mt-2 break-words text-sm font-semibold text-brew-brown">{value || "Not available"}</p>
    </div>
  );
}

function CustomersPage() {
  const { data, loading, error, refetch } = useCustomers();
  const [search, setSearch] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const lastNoResultQuery = useRef("");

  const filteredCustomers = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return data;
    }

    return data.filter((customer) =>
      [customer.name, customer.email, customer.city].some((value) =>
        String(value || "").toLowerCase().includes(query)
      )
    );
  }, [data, search]);

  useEffect(() => {
    const query = search.trim();

    if (!query || !data.length || filteredCustomers.length) {
      if (!query) {
        lastNoResultQuery.current = "";
      }
      return;
    }

    if (lastNoResultQuery.current !== query) {
      toast("No customers found for that search");
      lastNoResultQuery.current = query;
    }
  }, [data.length, filteredCustomers.length, search]);

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Customers" description="Search and review BrewCo customer profiles." />
        <LoadingSkeleton rows={5} />
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} onRetry={refetch} />;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Customers" description="Search and review BrewCo customer profiles." />

      <section className="rounded-lg border border-brew-brown/10 bg-brew-foam p-4 shadow-sm">
        <label className="text-sm font-medium text-brew-brown" htmlFor="customer-search">
          Search customers
        </label>
        <div className="relative mt-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brew-roast" />
          <input
            id="customer-search"
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search by name, email, or city"
            className="h-11 w-full rounded-md border border-brew-brown/15 bg-white pl-10 pr-3 text-sm text-brew-brown outline-none transition placeholder:text-brew-roast/60 focus:border-brew-amber focus:ring-2 focus:ring-brew-amber/20"
          />
        </div>
      </section>

      <div className="flex flex-col items-start gap-6 lg:flex-row">
        <div className="min-w-0 flex-1 w-full">
          {!data.length ? (
            <EmptyState
              icon={UserRound}
              title="No customers yet"
              description="Customer records from the backend will appear here once they are available."
            />
          ) : !filteredCustomers.length ? (
            <EmptyState
              icon={Search}
              title="No matching customers"
              description="Try a different name, email, or city search."
            />
          ) : (
            <section className="min-w-0 overflow-hidden rounded-lg border border-brew-brown/10 bg-brew-foam shadow-sm">
              <div className="min-w-0 overflow-x-auto">
                <table className="w-full divide-y divide-brew-brown/10 text-sm">
                  <thead className="bg-brew-cream text-left text-xs uppercase text-brew-roast">
                    <tr>
                      <th className="px-3 py-3 font-semibold">Name</th>
                      <th className="px-3 py-3 font-semibold">Email</th>
                      <th className="px-3 py-3 font-semibold">City</th>
                      <th className="px-3 py-3 font-semibold">Health</th>
                      <th className="px-2 py-3 text-right font-semibold">Orders</th>
                      <th className="px-2 py-3 text-right font-semibold">Spent</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-brew-brown/10">
                    {filteredCustomers.map((customer) => {
                      const health = getCustomerHealth(customer);
                      const isSelected = String(selectedCustomer?.id) === String(customer.id);

                      return (
                        <tr
                          key={customer.id}
                          onClick={() => setSelectedCustomer(customer)}
                          className={`cursor-pointer transition hover:bg-brew-cream/70 ${isSelected ? "row--selected" : ""}`}
                        >
                          <td className="px-3 py-4 font-medium text-brew-brown" title={customer.name}>{customer.name}</td>
                          <td className="px-3 py-4 text-brew-roast" title={customer.email}>{customer.email}</td>
                          <td className="px-3 py-4 text-brew-roast" title={customer.city || "Not available"}>{customer.city || "Not available"}</td>
                          <td className="whitespace-nowrap px-3 py-4">
                            <HealthBadge value={health} />
                          </td>
                          <td className="whitespace-nowrap px-2 py-4 text-right text-brew-brown">
                            {Number(customer.total_orders || 0).toLocaleString("en-US")}
                          </td>
                          <td className="whitespace-nowrap px-2 py-4 text-right font-semibold text-brew-brown">
                            {formatCurrency(customer.total_spent)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </div>

        {selectedCustomer && (
          <aside className="w-full shrink-0 lg:sticky lg:top-6 lg:w-[400px]">
            <div className="relative space-y-5 rounded-lg border border-brew-brown/10 bg-brew-foam p-5 shadow-sm">
              <button
                type="button"
                onClick={() => setSelectedCustomer(null)}
                className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-md text-brew-roast transition hover:bg-brew-cream hover:text-brew-brown"
              >
                <span className="sr-only">Close panel</span>
                <X size={18} />
              </button>

              <div className="mt-2 rounded-lg border border-brew-brown/10 bg-brew-cream p-5">
                <div className="flex flex-wrap items-start justify-between gap-4 pr-6">
                  <div className="min-w-0 flex-1">
                    <h3 className="break-words text-2xl font-bold text-brew-brown">{selectedCustomer.name}</h3>
                    <p className="mt-1 text-sm text-brew-roast">{selectedCustomer.city || "Not available"}</p>
                  </div>
                  <HealthBadge value={getCustomerHealth(selectedCustomer)} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <DetailItem className="col-span-2" icon={Mail} label="Email" value={selectedCustomer.email} />
                <DetailItem icon={MapPin} label="City" value={selectedCustomer.city} />
                <DetailItem icon={ShoppingBag} label="Total orders" value={Number(selectedCustomer.total_orders || 0).toLocaleString("en-US")} />
                <DetailItem icon={WalletCards} label="Total spent" value={formatCurrency(selectedCustomer.total_spent)} />
                <DetailItem icon={UserRound} label="Phone" value={selectedCustomer.phone} />
                <DetailItem icon={ShoppingBag} label="Last order" value={formatDate(selectedCustomer.last_order_date)} />
              </div>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}

export default CustomersPage;
